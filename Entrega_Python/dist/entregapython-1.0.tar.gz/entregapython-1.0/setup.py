from setuptools import setup

setup(
name="entregapython",
    version="1.0",
    description="Mi primer paquete de distribución",
    author="Karla Cumaco",
    author_email="cumacokarla@gmail.com",
    packages=["entregapython"],

)